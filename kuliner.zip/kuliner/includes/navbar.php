<nav>
<a href="?page=home" style="text-decoration: none;">Home</a> |
<a href="?page=makanan" style="text-decoration: none;">Makanan</a> |
<a href="?page=minuman" style="text-decoration: none;">Minuman</a> |
<a href="?page=about" style="text-decoration: none;">About</a> |
<a href="?page=contact" style="text-decoration: none;">Contact</a>
</nav>